export interface Proveedor {
    id: string;
    nombre: string;
    email: string;
    telefono: string;
    detalle: string;
    id_Usuario: string; 
  }