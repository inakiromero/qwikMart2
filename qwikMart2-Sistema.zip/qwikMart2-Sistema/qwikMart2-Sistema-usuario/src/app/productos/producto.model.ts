export interface Producto {
    id?: string;
    nombre: string;
    categoria: string;
    precio: number;
    stock: number;
    id_Usuario: string;
  }