export interface Usuario {
    id?: string;
    nombreMercado: string;
    cuit: string;
    email: string;
    password: string;
  }